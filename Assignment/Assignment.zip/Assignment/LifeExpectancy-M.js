const width = 640;
const height = 400;
const marginTop = 20;
const marginBottom = 30;
const marginLeft = 40;
const marginRight = 0;
const n = 10; // Number of countries to display
const duration = 2000;

const data = [
    { country: "Brunei Darussalam", lifeExpectancy: { 2020: 77.1, 2021: 76.3, 2022: 74.5 } },
    { country: "Cambodia", lifeExpectancy: { 2020: 69.9, 2021: 70.6, 2022: 71.2 } },
    { country: "Indonesia", lifeExpectancy: { 2020: 69.6, 2021: 69.7, 2022: 69.9 } },
    { country: "Lao", lifeExpectancy: { 2020: 65, 2021: 65, 2022: 66 } },
    { country: "Malaysia", lifeExpectancy: { 2020: 72.5, 2021: 72.3, 2022: 71.3 } },
    { country: "Myanmar", lifeExpectancy: { 2020: 62, 2021: 62.7, 2022: 62.8 } },
    { country: "Philippines", lifeExpectancy: { 2020: 71.3, 2021: 71.3, 2022: 71.3 } },
    { country: "Singapore", lifeExpectancy: { 2020: 81.3, 2021: 80.8, 2022: 80.7 } },
    { country: "Thailand", lifeExpectancy: { 2020: 72.4, 2021: 73.5, 2022: 73.6 } },
    { country: "Vietnam", lifeExpectancy: { 2020: 71, 2021: 71.1, 2022: 71.1 } }
];

const years = [2020, 2021, 2022];

const x = d3.scaleLinear()
    .range([marginLeft, width - marginRight]);

const y = d3.scaleBand()
    .domain(d3.range(n))
    .rangeRound([marginTop, height - marginBottom])
    .padding(0.1);

const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height]);

svg.append("g")
    .attr("transform", `translate(0, ${marginTop})`)
    .call(d3.axisTop(x).ticks(10));

const update = (year) => {
    const sortedData = data
        .map((d, i) => ({ country: d.country, value: d.lifeExpectancy[year], index: i }))
        .sort((a, b) => b.value - a.value)
        .slice(0, n);

    x.domain([0, d3.max(sortedData, d => d.value)]);

    // Update bars
    const bars = svg.selectAll(".bar")
        .data(sortedData, d => d.country);

    bars.enter().append("rect")
        .attr("class", "bar")
        .attr("x", marginLeft)
        .attr("y", (d, i) => y(i))
        .attr("height", y.bandwidth())
        .merge(bars)
        .transition()
        .duration(duration)
        .attr("width", d => x(d.value) - marginLeft)
        .attr("y", (d, i) => y(i));

    bars.exit().remove();

    // Update Y-axis
    svg.selectAll(".y-axis").remove();
    svg.append("g")
        .attr("class", "y-axis")
        .attr("transform", `translate(${marginLeft}, 0)`)
        .call(d3.axisLeft(y).tickFormat(i => data[i].country));
};

// Start animation
let currentYearIndex = 0;
const interval = setInterval(() => {
    update(years[currentYearIndex]);
    currentYearIndex = (currentYearIndex + 1) % years.length;
}, 2000); // Change every 2 seconds

// Initial draw
update(years[currentYearIndex]);
document.body.appendChild(svg.node());
