// Add console logging to help debug
console.log('Script starting...');

// Specify the size and padding of SVG
const width = 900;
const height = 500;
const margin = { top: 50, right: 120, bottom: 70, left: 80 };
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;

// Make sure the container exists and log result
const container = d3.select('#barchart');
console.log('Container found:', !container.empty());

// Clear any existing SVG
container.selectAll('svg').remove();

// Load and process the CSV file with error handling
console.log('Attempting to load CSV...');
d3.csv("data/LF - Total.csv")
    .then(function(rawData) {
        console.log('Raw data:', rawData);
        
        // Process the data to handle missing values and skip header rows
        const data = rawData
            .filter(d => d.Country && d.Country.trim() !== '' && d.Country !== 'Country') // Skip empty rows and header
            .map(d => {
                // Log each row to see what we're getting
                console.log('Processing row:', d);
                return {
                    Country: d.Country.trim(),
                    "2020": d["2020"] && d["2020"].trim() !== '-' ? parseFloat(d["2020"]) : null,
                    "2021": d["2021"] && d["2021"].trim() !== '-' ? parseFloat(d["2021"]) : null,
                    "2022": d["2022"] && d["2022"].trim() !== '-' ? parseFloat(d["2022"]) : null
                };
            })
            .filter(d => d["2020"] !== null || d["2021"] !== null || d["2022"] !== null);
        
        console.log('Processed data:', data);

        const years = ["2020", "2021", "2022"];
        const colors = ["#2196F3", "#64B5F6", "#90CAF9"];

        const svg = d3.select('#barchart')
            .append("svg")
            .attr('width', width)
            .attr('height', height);

        const g = svg.append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);

        // X scale
        const xScale = d3.scaleBand()
            .domain(data.map(d => d.Country))
            .range([0, innerWidth])
            .padding(0.2);

        const xScaleInner = d3.scaleBand()
            .domain(years)
            .range([0, xScale.bandwidth()])
            .padding(0.05);

        // Y scale
        const yScale = d3.scaleLinear()
            .domain([60, d3.max(data, d => 
                Math.max(...years.map(year => d[year] || 60))
            )])
            .range([innerHeight, 0])
            .nice();

        // Add title
        svg.append("text")
            .attr("class", "title_barchart")
            .attr('y', margin.top / 2)
            .attr('x', width / 2)
            .attr('text-anchor', 'middle')
            .text("Life Expectancy in SEA Countries (2020 - 2022)")
            .style('font-size', '24px');

        // Add axes
        g.append('g')
            .attr('transform', `translate(0,${innerHeight})`)
            .call(d3.axisBottom(xScale))
            .selectAll("text")
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .attr("transform", "rotate(-45)");

        g.append('g')
            .call(d3.axisLeft(yScale));

        // Add bars with logging
        data.forEach(d => {
            years.forEach((year, i) => {
                console.log(`Adding bar for ${d.Country}, ${year}: ${d[year]}`);
                if (d[year] !== null) {
                    const bar = g.append("rect")
                        .attr("x", xScale(d.Country) + xScaleInner(year))
                        .attr("y", yScale(d[year]))
                        .attr("width", xScaleInner.bandwidth())
                        .attr("height", innerHeight - yScale(d[year]))
                        .attr("fill", colors[i])
                        .attr("opacity", 0.8);
                    
                    console.log('Bar added:', {
                        country: d.Country,
                        year: year,
                        value: d[year],
                        x: xScale(d.Country) + xScaleInner(year),
                        y: yScale(d[year]),
                        width: xScaleInner.bandwidth(),
                        height: innerHeight - yScale(d[year])
                    });
                }
            });
        });

        // Add legend
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right + 20}, ${margin.top})`);

        years.forEach((year, i) => {
            legend.append('rect')
                .attr('x', 0)
                .attr('y', i * 20)
                .attr('width', 15)
                .attr('height', 15)
                .attr('fill', colors[i]);

            legend.append('text')
                .attr('x', 20)
                .attr('y', i * 20 + 12)
                .text(year);
        });
    })
    .catch(error => {
        console.error('Error loading or processing data:', error);
    });